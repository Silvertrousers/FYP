# Images to Triangles

The name says it all. The code for [this blog post](http://www.degeneratestate.org/posts/2017/May/24/images-to-triangles/).

Examples:

![original](BTD.jpg)

![50 points](BTD_triangle_50_points.jpg)

![100 points](BTD_triangle_100_points.jpg)

![500 points](BTD_triangle_500_points.jpg)
