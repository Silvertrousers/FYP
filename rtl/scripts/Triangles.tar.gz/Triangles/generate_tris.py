from triangulared import generate_max_entropy_points, get_triangle_colour, draw_triangles, set_axis_defaults, edge_points
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay
import argparse

def get_tris(input_path, n_points):
    image = plt.imread(input_path)
    points = generate_max_entropy_points(image, n_points=n_points)
    points = np.concatenate([points, edge_points(image)])

    tri = Delaunay(points)

    fig, ax = plt.subplots()
    ax.invert_yaxis()
    triangle_colours = get_triangle_colour(tri, image)
    return tri.points, tri.vertices, triangle_colours

def sort_tris(points, vertices, colours):
    vertices = np.copy(vertices)
    for i, idxs in enumerate(vertices):
        tri = points[idxs]
        orient_mat = np.hstack( (np.ones((3,1)), tri) )
        is_cw = (np.linalg.det(orient_mat) < 0)
        if not is_cw:
            vertices[i] = np.array([idxs[0], idxs[2], idxs[1]])
    return points, vertices, colours

def add_z(points):
    return np.hstack((points, np.zeros((len(points), 1))))

def main():
    tri = get_tris('/home/joff/Triangles/kitty-cat-kitten-pet-45201.jpeg', 10)
    points, vertices, colours = sort_tris(*tri)
    points = add_z(points)
    

if __name__ == "__main__":
    main()